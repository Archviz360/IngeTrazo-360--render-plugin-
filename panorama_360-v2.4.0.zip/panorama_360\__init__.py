# SPDX-License-Identifier: GPL-3.0-or-later
# Copyright (C) 2026 Marco Sumari Tellez and IngeTrazo contributors.
# Copyright (C) 2026 D.S (Archviz360).
"""360-degree image export - persistent cameras and native rendering.

The panel creates any number of cameras in the model, places/aims them with
snapping, previews their direction in the viewport and exports a selected
camera or a whole batch. Six 90-degree views from the native 2D exporter are
stitched into a true equirectangular panorama; no external renderer is used.
"""
from __future__ import annotations

import json
import math
import re
import tempfile
import uuid
import zipfile
from pathlib import Path

from PySide6.QtCore import QLineF, QPointF, QSettings, QSize, Qt, QTimer, QUrl
from PySide6.QtGui import (
    QAction, QColor, QDesktopServices, QFont, QIcon, QImage, QPainter, QPen,
    QPixmap, QVector3D,
)
from PySide6.QtWidgets import (
    QApplication, QCheckBox, QComboBox, QDoubleSpinBox, QFileDialog,
    QDialog, QDialogButtonBox, QFrame, QHBoxLayout, QLabel, QLineEdit,
    QListWidget, QListWidgetItem, QMessageBox, QProgressBar, QPushButton,
    QScrollArea, QToolBar, QVBoxLayout, QWidget,
)

from . import panorama_core as pano
from core.i18n import tr
from views.fold_section import FoldSection, narrow, wrapping_form


_SETTINGS = "panorama360/"
_PROJECTION_LABELS = (
    ("equirectangular", "Equirectangular 360 deg (2:1)"),
    ("cubemap_faces", "Cube map - six-face ZIP"),
    ("cubemap_strip", "Cube map - horizontal strip"),
    ("cubemap_cross", "Cube map - 4 x 3 cross"),
)


def _state(app) -> dict:
    raw = app.document_data({}) or {}
    return {"cameras": pano.clean_cameras(raw.get("cameras", []))
            if isinstance(raw, dict) else []}


def _store(app, cameras) -> None:
    app.set_document_data({"cameras": pano.clean_cameras(cameras)})


def _safe_name(value: str) -> str:
    value = re.sub(r"[^\w.-]+", "-", value.strip(), flags=re.UNICODE)
    return value.strip("-.") or "panorama"


def _pick_tool(prompt, done, cancelled):
    """A private snapping tool used for camera placement and aiming."""
    from tools.base import Tool

    class _Pick(Tool):
        name = prompt
        shortcut = None
        uses_snap = True

        def on_activate(self, viewport):
            pass

        def on_deactivate(self, viewport):
            pass

        def on_hover(self, ctx):
            ctx.viewport.update()

        def on_click(self, ctx):
            done(QVector3D(ctx.world))

        def on_key(self, viewport, key, modifiers):
            if key == Qt.Key_Escape:
                cancelled()
                return True
            return False

        def rubber_band_lines(self):
            return []

    return _Pick()


class PanoramaView(QWidget):
    """Mouse-draggable perspective window into an equirectangular image."""

    def __init__(self, image: QImage, parent=None) -> None:
        super().__init__(parent)
        source = image.scaled(4096, 2048, Qt.KeepAspectRatio,
                              Qt.SmoothTransformation)
        self._source = pano.prepare_equirectangular(source)
        self._frame = QImage()
        self._yaw = 0.0
        self._pitch = 0.0
        self._fov = 75.0
        self._press = None
        self.setMinimumSize(640, 360)
        self.setCursor(Qt.OpenHandCursor)
        self.setFocusPolicy(Qt.StrongFocus)
        self._timer = QTimer(self)
        self._timer.setSingleShot(True)
        self._timer.timeout.connect(self._render)
        self._schedule()

    def _schedule(self) -> None:
        if not self._timer.isActive():
            self._timer.start(0)

    def _render(self) -> None:
        if self.width() < 2 or self.height() < 2:
            return
        self._frame = pano.equirectangular_view(
            self._source, self.width(), self.height(), self._yaw,
            self._pitch, self._fov)
        self.update()

    def paintEvent(self, _event) -> None:
        painter = QPainter(self)
        painter.fillRect(self.rect(), QColor(12, 12, 12))
        if not self._frame.isNull():
            painter.drawImage(self.rect(), self._frame)
        painter.setPen(Qt.white)
        painter.drawText(12, 24, tr(
            "Heading {heading} deg | Tilt {tilt} deg | FOV {fov} deg",
            heading=int(self._yaw % 360), tilt=int(self._pitch),
            fov=int(self._fov)))
        painter.end()

    def resizeEvent(self, event) -> None:
        super().resizeEvent(event)
        self._schedule()

    def mousePressEvent(self, event) -> None:
        if event.button() == Qt.LeftButton:
            self._press = event.position()
            self.setCursor(Qt.ClosedHandCursor)
            event.accept()

    def mouseMoveEvent(self, event) -> None:
        if self._press is None:
            return
        pos = event.position()
        delta = pos - self._press
        self._press = pos
        self._yaw = (self._yaw - delta.x() * 0.18) % 360.0
        self._pitch = max(-89.0, min(89.0,
                                    self._pitch + delta.y() * 0.18))
        self._schedule()
        event.accept()

    def mouseReleaseEvent(self, event) -> None:
        if event.button() == Qt.LeftButton:
            self._press = None
            self.setCursor(Qt.OpenHandCursor)
            event.accept()

    def wheelEvent(self, event) -> None:
        steps = event.angleDelta().y() / 120.0
        self._fov = max(25.0, min(110.0, self._fov - steps * 5.0))
        self._schedule()
        event.accept()


class PanoramaPreviewDialog(QDialog):
    """Interactive approval dialog shown before a full-size export."""

    def __init__(self, image: QImage, camera_name: str, parent=None) -> None:
        super().__init__(parent)
        self.setWindowTitle(tr("Interactive 360 preview - {name}",
                               name=camera_name))
        self.resize(960, 620)
        layout = QVBoxLayout(self)
        layout.addWidget(PanoramaView(image, self), 1)
        help_label = QLabel(tr(
            "Drag to look around. Use the mouse wheel to zoom. This is a "
            "2K draft; the exported image uses the camera's saved settings."))
        help_label.setWordWrap(True)
        layout.addWidget(help_label)
        buttons = QDialogButtonBox(self)
        export = buttons.addButton(tr("Export full image..."),
                                   QDialogButtonBox.AcceptRole)
        buttons.addButton(tr("Close preview"), QDialogButtonBox.RejectRole)
        export.setDefault(True)
        buttons.accepted.connect(self.accept)
        buttons.rejected.connect(self.reject)
        layout.addWidget(buttons)


class PanoramaPanel(QWidget):
    def __init__(self, app) -> None:
        super().__init__()
        self.app = app
        self._queue = []
        self._result = None
        self._view_pick = None
        self._picking = None
        self._view_before_preview = None
        self._thumbnails = {}
        self._thumbnail_busy = False
        self._loading_camera = False
        self._build_ui()
        self.refresh()

    def _build_ui(self) -> None:
        outer = QVBoxLayout(self)
        outer.setContentsMargins(0, 0, 0, 0)
        scroll = QScrollArea()
        scroll.setWidgetResizable(True)
        scroll.setFrameShape(QFrame.NoFrame)
        scroll.setHorizontalScrollBarPolicy(Qt.ScrollBarAlwaysOff)
        outer.addWidget(scroll)
        body = QWidget()
        scroll.setWidget(body)
        lay = QVBoxLayout(body)
        lay.setContentsMargins(8, 6, 8, 8)
        settings = QSettings()

        # Cameras live in the document and therefore follow copies and saves.
        sec = FoldSection(tr("360 cameras"), _SETTINGS + "open_cameras")
        box = QVBoxLayout(sec.body)
        self._cameras = QListWidget()
        self._cameras.setMinimumHeight(150)
        self._cameras.setIconSize(QSize(112, 63))
        self._cameras.setSpacing(3)
        self._cameras.currentRowChanged.connect(self._selected)
        box.addWidget(self._cameras)
        row = QHBoxLayout()
        add = QPushButton(tr("+ From view"))
        add.setToolTip(tr("Create a 360 camera at the current viewport eye"))
        add.clicked.connect(self._add_from_view)
        place = QPushButton(tr("+ Place..."))
        place.setToolTip(tr("Click a floor point; eye height is added"))
        place.clicked.connect(lambda: self._begin_pick("new"))
        row.addWidget(add)
        row.addWidget(place)
        box.addLayout(row)
        thumbnails = QPushButton(tr("Refresh camera thumbnails"))
        thumbnails.setToolTip(tr(
            "Capture a new gallery thumbnail for every saved camera"))
        thumbnails.clicked.connect(self.refresh_thumbnails)
        box.addWidget(thumbnails)

        self._editor = QWidget()
        form = wrapping_form(self._editor)
        form.setContentsMargins(0, 0, 0, 0)
        self._name = QLineEdit()
        self._name.editingFinished.connect(self._edited)
        form.addRow(tr("Name:"), self._name)
        posrow = QHBoxLayout()
        self._xyz = []
        for axis in "XYZ":
            spin = QDoubleSpinBox()
            spin.setRange(-1e8, 1e8)
            spin.setDecimals(3)
            spin.setSuffix(" m")
            spin.setToolTip(axis)
            spin.editingFinished.connect(self._edited)
            self._xyz.append(spin)
            posrow.addWidget(spin)
        form.addRow(tr("Position:"), posrow)
        self._heading = QDoubleSpinBox()
        self._heading.setRange(0.0, 359.9)
        self._heading.setDecimals(1)
        self._heading.setWrapping(True)
        self._heading.setSuffix(" deg")
        self._heading.setToolTip(tr("0 deg north, 90 deg east"))
        self._heading.editingFinished.connect(self._edited)
        form.addRow(tr("Heading:"), self._heading)
        self._tilt = QDoubleSpinBox()
        self._tilt.setRange(-90.0, 90.0)
        self._tilt.setDecimals(1)
        self._tilt.setSuffix(" deg")
        self._tilt.setToolTip(tr(
            "Used by camera preview; 360 export levels the horizon automatically"))
        self._tilt.editingFinished.connect(self._edited)
        form.addRow(tr("Tilt:"), self._tilt)
        self._eye_height = QDoubleSpinBox()
        self._eye_height.setRange(0.0, 20.0)
        self._eye_height.setDecimals(2)
        self._eye_height.setValue(float(settings.value(
            _SETTINGS + "eye_height", 1.65)))
        self._eye_height.setSuffix(" m")
        form.addRow(tr("Placement eye height:"), self._eye_height)
        row = QHBoxLayout()
        move = QPushButton(tr("Move..."))
        move.clicked.connect(lambda: self._begin_pick("move"))
        aim = QPushButton(tr("Aim..."))
        aim.clicked.connect(lambda: self._begin_pick("aim"))
        row.addWidget(move)
        row.addWidget(aim)
        form.addRow(row)
        row = QHBoxLayout()
        self._preview_button = QPushButton(tr("View camera preview"))
        self._preview_button.setToolTip(tr(
            "View from the selected camera with the 90-degree capture lens"))
        self._preview_button.clicked.connect(self._start_preview)
        self._normal_view_button = QPushButton(tr("Back to normal view"))
        self._normal_view_button.setToolTip(tr(
            "Restore the perspective view from before the camera preview"))
        self._normal_view_button.clicked.connect(self._stop_preview)
        self._normal_view_button.setEnabled(False)
        row.addWidget(self._preview_button)
        row.addWidget(self._normal_view_button)
        form.addRow(row)
        self._preview_status = QLabel(tr("Camera preview is off."))
        self._preview_status.setWordWrap(True)
        self._preview_status.setStyleSheet("color: palette(mid);")
        form.addRow(self._preview_status)
        row = QHBoxLayout()
        update = QPushButton(tr("Update from view"))
        update.clicked.connect(self._update_from_view)
        duplicate = QPushButton(tr("Duplicate"))
        duplicate.clicked.connect(self._duplicate)
        delete = QPushButton(tr("Delete"))
        delete.clicked.connect(self._delete)
        row.addWidget(update)
        row.addWidget(duplicate)
        row.addWidget(delete)
        form.addRow(row)
        box.addWidget(self._editor)
        lay.addWidget(sec)

        # Every camera keeps its own projection, image and destination settings.
        sec = FoldSection(tr("Projection and image"), _SETTINGS + "open_image")
        form = wrapping_form(sec.body)
        per_camera = QLabel(tr("These settings are saved with the selected camera."))
        per_camera.setWordWrap(True)
        per_camera.setStyleSheet("color: palette(mid);")
        form.addRow(per_camera)
        self._projection = QComboBox()
        for key, label in _PROJECTION_LABELS:
            self._projection.addItem(tr(label), key)
        self._set_combo(self._projection, settings.value(
            _SETTINGS + "projection", "equirectangular"))
        self._projection.currentIndexChanged.connect(
            self._export_settings_changed)
        form.addRow(tr("Projection:"), self._projection)
        self._resolution = QComboBox()
        for label, px in (("2K", 2048), ("4K", 4096), ("6K", 6144),
                          ("8K", 8192), ("12K", 12288), ("16K", 16384)):
            self._resolution.addItem(label, px)
        wanted = int(settings.value(_SETTINGS + "width", 4096))
        self._resolution.setCurrentIndex(max(0, self._resolution.findData(wanted)))
        self._resolution.currentIndexChanged.connect(
            self._export_settings_changed)
        self._size = QLabel()
        rrow = QHBoxLayout()
        rrow.addWidget(self._resolution, 1)
        rrow.addWidget(self._size)
        form.addRow(tr("Resolution:"), rrow)
        self._format = QComboBox()
        for label, key in (("PNG", "png"), ("JPEG", "jpeg")):
            self._format.addItem(label, key)
        self._set_combo(self._format, settings.value(_SETTINGS + "format", "png"))
        self._format.currentIndexChanged.connect(self._export_settings_changed)
        form.addRow(tr("Format:"), self._format)
        folder_row = QHBoxLayout()
        self._output_folder = QLineEdit()
        self._output_folder.setPlaceholderText(tr("Choose an output folder"))
        self._output_folder.setText(str(settings.value(
            _SETTINGS + "folder", "")))
        self._output_folder.editingFinished.connect(
            self._export_settings_changed)
        self._folder_button = QPushButton(tr("Browse..."))
        self._folder_button.clicked.connect(self._choose_output_folder)
        folder_row.addWidget(self._output_folder, 1)
        folder_row.addWidget(self._folder_button)
        form.addRow(tr("Output folder:"), folder_row)
        self._auto_level = QCheckBox(tr("Auto-level horizon (always on)"))
        self._auto_level.setChecked(True)
        self._auto_level.setEnabled(False)
        self._auto_level.setToolTip(tr(
            "Keeps the panorama horizon horizontal even if the viewport "
            "camera was looking up or down"))
        form.addRow(self._auto_level)
        self._metadata = QCheckBox(tr("Write metadata sidecar"))
        self._metadata.setChecked(str(settings.value(_SETTINGS + "metadata", "1")) != "0")
        form.addRow(self._metadata)
        lay.addWidget(sec)

        self._export_settings = (
            self._projection, self._resolution, self._format,
            self._output_folder, self._folder_button, self._metadata,
        )

        sec = FoldSection(tr("Export"), _SETTINGS + "open_export")
        box = QVBoxLayout(sec.body)
        lighting = QLabel(tr(
            "Uses IngeTrazo's native 2D image renderer. No Blender or other "
            "software is required."))
        lighting.setWordWrap(True)
        lighting.setStyleSheet("color: palette(mid);")
        box.addWidget(lighting)
        self._where = QLabel()
        self._where.setWordWrap(True)
        box.addWidget(self._where)
        self._interactive = QPushButton(tr("Interactive 360 preview..."))
        self._interactive.setToolTip(tr(
            "Render a draggable 2K panorama preview before exporting"))
        self._interactive.clicked.connect(self._interactive_preview)
        self._go = QPushButton(tr("Export selected 360..."))
        self._go.clicked.connect(self._export_selected)
        self._all = QPushButton(tr("Export all cameras..."))
        self._all.clicked.connect(self._export_all)
        box.addWidget(self._interactive)
        box.addWidget(self._go)
        box.addWidget(self._all)
        self._bar = QProgressBar()
        self._bar.setRange(0, 1000)
        self._bar.setVisible(False)
        box.addWidget(self._bar)
        self._status = QLabel()
        self._status.setWordWrap(True)
        self._status.setTextFormat(Qt.RichText)
        self._status.linkActivated.connect(self._open_result)
        box.addWidget(self._status)
        lay.addWidget(sec)
        lay.addStretch(1)
        narrow(self._name, self._projection, self._resolution, self._format,
               self._output_folder, self._interactive, self._go, self._all,
               self._status)
        self._projection_changed()
        self._update_renderer_label()

    @staticmethod
    def _set_combo(combo, data) -> None:
        i = combo.findData(data)
        combo.setCurrentIndex(max(0, i))

    # ---- Cameras ----------------------------------------------------------
    def cameras(self):
        return _state(self.app)["cameras"]

    def selected_index(self):
        row = self._cameras.currentRow()
        return row if 0 <= row < len(self.cameras()) else None

    def selected_camera(self):
        i = self.selected_index()
        cams = self.cameras()
        return cams[i] if i is not None and i < len(cams) else None

    def refresh(self) -> None:
        chosen = self.selected_camera()
        chosen_id = chosen["id"] if chosen else None
        cams = self.cameras()
        valid_ids = {cam["id"] for cam in cams}
        self._thumbnails = {key: value for key, value in self._thumbnails.items()
                            if key in valid_ids}
        self._cameras.blockSignals(True)
        self._cameras.clear()
        for cam in cams:
            item = QListWidgetItem(self._camera_item_text(cam))
            thumbnail = self._thumbnails.get(cam["id"])
            if thumbnail is not None and not thumbnail.isNull():
                item.setIcon(QIcon(QPixmap.fromImage(thumbnail)))
            self._cameras.addItem(item)
        row = next((i for i, c in enumerate(cams) if c["id"] == chosen_id), 0)
        self._cameras.setCurrentRow(row if cams else -1)
        self._cameras.blockSignals(False)
        self._selected(self._cameras.currentRow())
        self._view_pick = None
        self.app.release_pick()
        self.app.viewport.update()
        QTimer.singleShot(0, self._capture_missing_thumbnails)

    @staticmethod
    def _camera_item_text(camera) -> str:
        export = pano.clean_export_settings(camera.get("export"))
        projection = export["projection"].replace("_", " ")
        return (f'{camera["name"]}\n{export["width"]} px | '
                f'{export["format"].upper()} | {projection}')

    def _capture_missing_thumbnails(self) -> None:
        if self._thumbnail_busy:
            return
        missing = [(i, cam) for i, cam in enumerate(self.cameras())
                   if cam["id"] not in self._thumbnails]
        if not missing:
            return
        self._thumbnail_busy = True
        try:
            for index, cam in missing:
                try:
                    image = pano.render_camera_image(
                        self.app.viewport, cam, 224, 126, fov=90.0)
                except Exception:
                    continue
                self._thumbnails[cam["id"]] = image
                item = self._cameras.item(index)
                if item is not None:
                    item.setIcon(QIcon(QPixmap.fromImage(image)))
                QApplication.processEvents()
        finally:
            self._thumbnail_busy = False

    def refresh_thumbnails(self) -> None:
        self._thumbnails.clear()
        for index in range(self._cameras.count()):
            self._cameras.item(index).setIcon(QIcon())
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            self._capture_missing_thumbnails()
        finally:
            QApplication.restoreOverrideCursor()

    def _selected(self, row) -> None:
        cams = self.cameras()
        on = 0 <= row < len(cams)
        self._editor.setEnabled(on)
        if on:
            cam = cams[row]
            export = pano.clean_export_settings(cam.get("export"))
            controls = [self._name, *self._xyz, self._heading, self._tilt]
            for w in controls:
                w.blockSignals(True)
            self._name.setText(cam["name"])
            for spin, value in zip(self._xyz, cam["pos"]):
                spin.setValue(value)
            self._heading.setValue(cam["heading"])
            self._tilt.setValue(cam["tilt"])
            for w in controls:
                w.blockSignals(False)
            self._loading_camera = True
            for widget in (self._projection, self._resolution, self._format,
                           self._output_folder):
                widget.blockSignals(True)
            self._set_combo(self._projection, export["projection"])
            self._set_combo(self._resolution, export["width"])
            self._set_combo(self._format, export["format"])
            self._output_folder.setText(export["folder"])
            for widget in (self._projection, self._resolution, self._format,
                           self._output_folder):
                widget.blockSignals(False)
            self._loading_camera = False
            self._update_size_label()
            if self._view_before_preview is not None:
                self._apply_preview(cam)
        elif self._view_before_preview is not None:
            self._stop_preview()
        self.app.viewport.update()

    def _view_values(self):
        cam = self.app.viewport.camera
        eye, d = cam.eye(), cam.forward()
        heading = math.degrees(math.atan2(d.x(), d.y())) % 360.0
        tilt = math.degrees(math.asin(max(-1.0, min(1.0, d.z()))))
        return [eye.x(), eye.y(), eye.z()], heading, tilt

    def _new_camera(self, pos, heading, tilt, name=None, export=None):
        cams = self.cameras()
        cams.append({"id": uuid.uuid4().hex, "name": name or tr(
            "360 Camera {n}", n=len(cams) + 1), "pos": list(pos),
            "heading": heading, "tilt": tilt,
            "export": pano.clean_export_settings(
                export if export is not None else self._current_export_settings())})
        _store(self.app, cams)
        self._cameras.setCurrentRow(len(cams) - 1)

    def _add_from_view(self):
        self._new_camera(*self._view_values())

    def _update_from_view(self):
        i = self.selected_index()
        if i is None:
            return
        cams = self.cameras()
        self._thumbnails.pop(cams[i]["id"], None)
        cams[i]["pos"], cams[i]["heading"], cams[i]["tilt"] = self._view_values()
        _store(self.app, cams)

    def _duplicate(self):
        cam = self.selected_camera()
        if cam is None:
            return
        pos = list(cam["pos"])
        pos[0] += 0.25
        self._new_camera(pos, cam["heading"], cam["tilt"],
                         cam["name"] + " " + tr("copy"), cam.get("export"))

    def _delete(self):
        i = self.selected_index()
        if i is None:
            return
        if self._view_before_preview is not None:
            self._stop_preview()
        cams = self.cameras()
        self._thumbnails.pop(cams[i]["id"], None)
        del cams[i]
        _store(self.app, cams)

    def _edited(self):
        i = self.selected_index()
        cams = self.cameras()
        if i is None or i >= len(cams):
            return
        cam = cams[i]
        self._thumbnails.pop(cam["id"], None)
        cam.update(name=self._name.text().strip() or cam["name"],
                   pos=[s.value() for s in self._xyz],
                   heading=self._heading.value(), tilt=self._tilt.value())
        _store(self.app, cams)
        if self._view_before_preview is not None:
            self._apply_preview(cam)

    def _apply_preview(self, cam):
        pano.preview_view(self.app.viewport.camera, cam, fov=90.0)
        self._preview_status.setText(tr(
            "Previewing {name} with a 90-degree lens.", name=cam["name"]))
        self.app.viewport.update()
        self.app.viewport.setFocus()

    def _start_preview(self):
        cam = self.selected_camera()
        if cam is None:
            return
        if self._view_before_preview is None:
            self._view_before_preview = pano.capture_view(
                self.app.viewport.camera)
        self._normal_view_button.setEnabled(True)
        self._apply_preview(cam)

    def _stop_preview(self):
        if self._view_before_preview is None:
            return
        pano.restore_view(self.app.viewport.camera, self._view_before_preview)
        self._view_before_preview = None
        self._normal_view_button.setEnabled(False)
        self._preview_status.setText(tr("Camera preview is off."))
        self.app.viewport.update()
        self.app.viewport.setFocus()

    def _begin_pick(self, purpose):
        if purpose != "new" and self.selected_camera() is None:
            return
        self._picking = purpose
        prompts = {"new": tr("Click the floor under the 360 camera"),
                   "move": tr("Click the camera's new floor point"),
                   "aim": tr("Click where the camera looks")}
        self.app.viewport.set_active_tool(_pick_tool(
            prompts[purpose], self._picked, self._end_pick))
        self.app.window.statusBar().showMessage(prompts[purpose] + " - " + tr("Esc cancels"))
        self.app.viewport.setFocus()

    def _picked(self, point):
        purpose = self._picking
        if purpose == "new":
            _pos, heading, tilt = self._view_values()
            self._new_camera((point.x(), point.y(), point.z() + self._eye_height.value()),
                             heading, tilt)
        else:
            i, cams = self.selected_index(), self.cameras()
            if i is not None:
                cam = cams[i]
                self._thumbnails.pop(cam["id"], None)
                if purpose == "move":
                    cam["pos"] = [point.x(), point.y(),
                                  point.z() + self._eye_height.value()]
                elif purpose == "aim":
                    d = point - QVector3D(*cam["pos"])
                    if d.lengthSquared() > 1e-12:
                        d.normalize()
                        cam["heading"] = math.degrees(math.atan2(d.x(), d.y())) % 360.0
                        cam["tilt"] = math.degrees(math.asin(d.z()))
                _store(self.app, cams)
        self._end_pick()

    def _end_pick(self):
        self._picking = None
        self.app.window.statusBar().clearMessage()
        activate = getattr(self.app.window, "_activate_tool", None)
        if callable(activate):
            activate("select")

    # ---- Settings ---------------------------------------------------------
    def _projection_changed(self):
        self._update_size_label()

    def _current_export_settings(self) -> dict:
        return pano.clean_export_settings({
            "projection": self._projection.currentData(),
            "width": self._resolution.currentData(),
            "format": self._format.currentData(),
            "folder": self._output_folder.text(),
        })

    def _export_settings_changed(self, *_args) -> None:
        self._update_size_label()
        if self._loading_camera:
            return
        i = self.selected_index()
        cams = self.cameras()
        if i is None or i >= len(cams):
            return
        cams[i]["export"] = self._current_export_settings()
        self._remember()
        _store(self.app, cams)

    def _choose_output_folder(self) -> None:
        current = self._output_folder.text().strip()
        if not current:
            document = getattr(self.app.window, "_current_path", None)
            current = str(Path(document).parent if document else Path.home())
        folder = QFileDialog.getExistingDirectory(
            self, tr("Choose this camera's output folder"), current)
        if folder:
            self._output_folder.setText(folder)
            self._export_settings_changed()

    def _update_size_label(self):
        key = self._projection.currentData()
        width = int(self._resolution.currentData() or 4096)
        w, h = pano.dimensions(key, width)
        suffix = tr("final") if key not in pano.CUBE_PROJECTIONS else tr("face / final")
        self._size.setText(f"{w} x {h} px {suffix}")

    def _remember(self):
        s = QSettings()
        values = {
            "projection": self._projection.currentData(),
            "width": self._resolution.currentData(),
            "format": self._format.currentData(),
            "folder": self._output_folder.text().strip(),
            "metadata": int(self._metadata.isChecked()),
            "eye_height": self._eye_height.value(),
        }
        for key, value in values.items():
            s.setValue(_SETTINGS + key, value)

    def _update_renderer_label(self):
        self._where.setText(tr(
            "Native 360 export is ready. Each camera keeps its own settings."))

    # ---- Export -----------------------------------------------------------
    @staticmethod
    def _destination_suffix(camera):
        export = pano.clean_export_settings(camera.get("export"))
        if export["projection"] == "cubemap_faces":
            return ".zip"
        return pano.FORMATS[export["format"]]["suffix"]

    def _interactive_preview(self):
        camera = self.selected_camera()
        if camera is None:
            QMessageBox.information(
                self, tr("360 preview"), tr("Create or select a camera first."))
            return
        self._remember()
        self._result = None
        self._set_running(True)
        self._status.setText(tr(
            "Rendering interactive preview for {name}...",
            name=camera["name"]))
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            faces = pano.render_cube_faces(
                self.app.viewport, camera, 512, overlays=False,
                auto_level=True)
            self._bar.setValue(350)
            image = pano.cube_to_equirectangular(
                faces, 2048,
                progress=lambda value: self._bar.setValue(
                    int((0.35 + value * 0.65) * 1000)))
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, tr("360 preview"), str(exc))
            self._status.setText(tr("360 preview failed."))
            return
        finally:
            QApplication.restoreOverrideCursor()
            self._set_running(False)
        self._status.setText(tr("Interactive preview is ready."))
        dialog = PanoramaPreviewDialog(image, camera["name"], self)
        if dialog.exec() == QDialog.Accepted:
            self._export_selected()

    def _export_selected(self):
        cam = self.selected_camera()
        if cam is None:
            QMessageBox.information(self, tr("360 export"), tr("Create or select a camera first."))
            return
        export = pano.clean_export_settings(cam.get("export"))
        suffix = self._destination_suffix(cam)
        doc = getattr(self.app.window, "_current_path", None)
        base = (Path(export["folder"]) if export["folder"] else
                (Path(doc).parent if doc else Path.home()))
        start = base / (_safe_name(cam["name"]) + suffix)
        path, _ = QFileDialog.getSaveFileName(
            self, tr("Export 360 image"), str(start),
            tr("360 output (*{suffix});;All files (*)", suffix=suffix))
        if path:
            path = Path(path)
            if not path.suffix:
                path = path.with_suffix(suffix)
            export["folder"] = str(path.parent)
            cam["export"] = export
            cams = self.cameras()
            i = self.selected_index()
            if i is not None and i < len(cams):
                cams[i]["export"] = export
                _store(self.app, cams)
            self._start_queue([(cam, path)])

    def _export_all(self):
        cams = self.cameras()
        if not cams:
            QMessageBox.information(self, tr("360 export"), tr("Create a camera first."))
            return
        missing_folder = any(not pano.clean_export_settings(
            cam.get("export"))["folder"] for cam in cams)
        fallback = ""
        if missing_folder:
            document = getattr(self.app.window, "_current_path", None)
            start = str(Path(document).parent if document else Path.home())
            fallback = QFileDialog.getExistingDirectory(
                self, tr("Choose a folder for cameras without one"), start)
            if not fallback:
                return
        used = set()
        jobs = []
        for cam in cams:
            export = pano.clean_export_settings(cam.get("export"))
            folder = Path(export["folder"] or fallback)
            suffix = self._destination_suffix(cam)
            stem, n = _safe_name(cam["name"]), 2
            unique = stem
            key = (str(folder).casefold(), unique.casefold())
            while key in used:
                unique, n = f"{stem}-{n}", n + 1
                key = (str(folder).casefold(), unique.casefold())
            used.add(key)
            jobs.append((cam, folder / (unique + suffix)))
        self._start_queue(jobs)

    def _start_queue(self, jobs):
        self._remember()
        self._queue = list(jobs)
        self._result = None
        self._set_running(True)
        QApplication.setOverrideCursor(Qt.WaitCursor)
        try:
            total = len(self._queue)
            for index, (camera, destination) in enumerate(self._queue, 1):
                self._status.setText(tr(
                    "Rendering {name} with IngeTrazo...", name=camera["name"]))
                QApplication.processEvents()
                self._native_export(camera, Path(destination), index, total)
                self._result = Path(destination)
        except Exception as exc:  # noqa: BLE001
            QMessageBox.critical(self, tr("360 export"), str(exc))
            self._status.setText(tr("360 export failed."))
            return
        finally:
            self._queue.clear()
            QApplication.restoreOverrideCursor()
            self._set_running(False)
        self._status.setText(tr("Export complete.") + ' <a href="#open">' +
                             tr("Open result") + "</a>")

    def _native_export(self, camera, destination: Path,
                       job_index: int, job_total: int) -> None:
        """Capture six native 2D views and assemble one true 360 image."""
        export = pano.clean_export_settings(camera.get("export"))
        projection = export["projection"]
        width = export["width"]
        face_size = (width if projection in pano.CUBE_PROJECTIONS
                     else max(256, width // 4))
        base = (job_index - 1) / max(job_total, 1)
        span = 1.0 / max(job_total, 1)
        faces = pano.render_cube_faces(self.app.viewport, camera, face_size,
                                       overlays=False, auto_level=True)
        self._bar.setValue(int((base + span * 0.35) * 1000))
        destination.parent.mkdir(parents=True, exist_ok=True)
        fmt = export["format"]
        meta = pano.manifest(camera, projection, width, fmt)
        with tempfile.TemporaryDirectory(prefix="ingetrazo-360-") as folder:
            folder = Path(folder)
            suffix = pano.FORMATS[fmt]["suffix"]
            paths = {}
            for name, image in faces.items():
                path = folder / (name + suffix)
                if not image.save(str(path), None, 95):
                    raise RuntimeError(tr("Could not save cube face {name}.",
                                          name=name))
                paths[name] = path
            if projection == "equirectangular":
                image = pano.cube_to_equirectangular(
                    faces, width, progress=lambda value: self._bar.setValue(
                        int((base + span * (0.35 + value * 0.65)) * 1000)))
                if not image.save(str(destination), None, 95):
                    raise RuntimeError(tr("Could not save the 360 image."))
                if fmt == "jpeg":
                    pano.add_gpano_xmp(destination, width, width // 2)
            elif projection == "cubemap_faces":
                with zipfile.ZipFile(destination, "w",
                                     zipfile.ZIP_DEFLATED) as archive:
                    for name, path in paths.items():
                        archive.write(path, "faces/" + path.name)
                    archive.writestr("manifest.json",
                                     json.dumps(meta, indent=2))
            else:
                self._compose_cube(paths, destination, projection, face_size)
        if self._metadata.isChecked() and projection != "cubemap_faces":
            destination.with_suffix(destination.suffix + ".json").write_text(
                json.dumps(meta, indent=2), encoding="utf-8")
        self._bar.setValue(int((base + span) * 1000))

    @staticmethod
    def _compose_cube(faces, destination, projection, size):
        images = {name: QImage(str(path)) for name, path in faces.items()}
        bad = [name for name, image in images.items() if image.isNull()]
        if bad:
            raise RuntimeError("Could not read cube faces: " + ", ".join(bad))
        if projection == "cubemap_strip":
            canvas = QImage(size * 6, size, QImage.Format_RGBA8888)
            slots = [(name, i, 0) for i, name in enumerate(
                ("front", "right", "back", "left", "up", "down"))]
        else:
            canvas = QImage(size * 4, size * 3, QImage.Format_RGBA8888)
            slots = [("up", 1, 0), ("left", 0, 1), ("front", 1, 1),
                     ("right", 2, 1), ("back", 3, 1), ("down", 1, 2)]
        canvas.fill(Qt.transparent)
        painter = QPainter(canvas)
        for name, x, y in slots:
            painter.drawImage(x * size, y * size, images[name])
        painter.end()
        if not canvas.save(str(destination)):
            raise RuntimeError("Could not save " + str(destination))

    def _set_running(self, running):
        self._bar.setVisible(running)
        self._interactive.setVisible(not running)
        self._go.setVisible(not running)
        self._all.setVisible(not running)
        for widget in self._export_settings:
            widget.setEnabled(not running)
        if not running:
            self._projection_changed()

    def _open_result(self, _link=None):
        if self._result is not None:
            QDesktopServices.openUrl(QUrl.fromLocalFile(str(self._result)))

    # ---- Selectable viewport camera icons --------------------------------
    def pick_camera(self, viewport, px, py):
        best, distance = None, 14.0
        for i, cam in enumerate(self.cameras()):
            p = viewport._world_to_pixel(QVector3D(*cam["pos"]))
            if p is None:
                continue
            d = math.hypot(p[0] - px, p[1] - py)
            if d <= distance:
                best, distance = i, d
        return best

    def camera_picked(self, index):
        self._view_pick = index
        if index is not None and 0 <= index < self._cameras.count():
            self._cameras.setCurrentRow(index)
        self.app.viewport.update()

    def delete_camera_at(self, index):
        cams = self.cameras()
        if 0 <= index < len(cams):
            if self._view_before_preview is not None:
                self._stop_preview()
            self._thumbnails.pop(cams[index]["id"], None)
            del cams[index]
            _store(self.app, cams)


def draw_cameras(panel, viewport, painter):
    if panel._view_before_preview is not None:
        return
    cams = panel.cameras()
    selected = panel.selected_index()
    painter.setRenderHint(QPainter.Antialiasing)
    font = QFont()
    font.setPointSize(8)
    painter.setFont(font)
    for i, cam in enumerate(cams):
        pos = QVector3D(*cam["pos"])
        p = viewport._world_to_pixel(pos)
        tip = viewport._world_to_pixel(pos + pano.direction(cam) * 0.8)
        if p is None:
            continue
        color = QColor(122, 74, 190)
        painter.setPen(QPen(color, 2.0))
        painter.setBrush(QColor(205, 184, 235, 210))
        centre = QPointF(p[0], p[1])
        painter.drawEllipse(centre, 7.0, 7.0)
        if tip is not None:
            painter.drawLine(QLineF(centre, QPointF(tip[0], tip[1])))
        if i == panel._view_pick:
            painter.setBrush(Qt.NoBrush)
            painter.setPen(QPen(QColor(242, 115, 41), 3.0))
            painter.drawEllipse(centre, 15.0, 15.0)
        if i == selected:
            painter.setPen(QPen(QColor(45, 45, 45)))
            painter.drawText(QPointF(p[0] + 12, p[1] - 9), cam["name"])


def _plugin_icon() -> QIcon:
    """Load the supplied Archviz360 artwork in source and packaged layouts."""
    here = Path(__file__).resolve()
    for candidate in (here.with_name("icon.png"),
                      here.with_name("panorama_360_icon.png")):
        if candidate.is_file():
            icon = QIcon(str(candidate))
            if not icon.isNull():
                return icon
    return QIcon()


def _install_toolbar(app, dock) -> None:
    """Add an independently movable, dockable 360 Export logo button."""
    window = getattr(app, "window", None)
    if window is None or not hasattr(window, "addToolBar"):
        return

    object_name = "extension_panorama_360_toolbar"
    if window.findChild(QToolBar, object_name) is not None:
        return

    toolbar = None
    maker = getattr(window, "_new_toolbar", None)
    if callable(maker):
        try:
            toolbar = maker(tr("360 Export"), object_name)
        except Exception:
            toolbar = None
    if toolbar is None:
        toolbar = QToolBar(tr("360 Export"), window)
        toolbar.setObjectName(object_name)
        toolbar.setMovable(True)
        toolbar.setFloatable(True)
        toolbar.setAllowedAreas(Qt.AllToolBarAreas)
        reference = next((item for item in window.findChildren(QToolBar)
                          if item is not toolbar), None)
        toolbar.setIconSize(reference.iconSize() if reference else QSize(32, 32))
        toolbar.setToolButtonStyle(Qt.ToolButtonIconOnly)
        window.addToolBar(Qt.TopToolBarArea, toolbar)

    action = QAction(_plugin_icon(), tr("360 Export"), window)
    tip = tr("Open 360 Export cameras and panorama settings.")
    action.setToolTip(tip)
    action.setStatusTip(tip)
    action.triggered.connect(lambda _checked=False: app.show_panel(dock))
    toolbar.addAction(action)
    toolbar._panorama_360_refs = (action, dock)


def setup(app) -> None:
    panel = PanoramaPanel(app)
    dock = app.add_panel(tr("360 Export"), panel)
    menu_action = app.add_menu_action(
        tr("Export 360 images..."), lambda: app.show_panel(dock),
        tip=tr("Create panorama cameras and export immersive images."))
    if menu_action is not None:
        menu_action.setIcon(_plugin_icon())
    _install_toolbar(app, dock)
    app.on_document_changed(panel.refresh)
    app.add_overlay(lambda vp, painter: draw_cameras(panel, vp, painter))
    app.add_pickable(panel.pick_camera, on_select=panel.camera_picked,
                     delete=panel.delete_camera_at)
